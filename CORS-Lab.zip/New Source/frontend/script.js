document.getElementById('fetchDataBtn').addEventListener('click', () => {
  fetch('http://192.168.10.101:5000/api/data')
    .then(response => response.json())
    .then(data => {
      document.getElementById('output').textContent = JSON.stringify(data, null, 2);
    })
    .catch(error => {
      document.getElementById('output').textContent = `CORS Error: ${error}`;
    });
});

