const express = require('express');
const cors = require('cors');
const app = express();

//List allowed domains
const allowedDomains = ['http://192.168.10.100'];

const corsOptions = {
	origin: (origin, callback) => {
		if(!origin || allowedDomains.includes(origin)) {
			callback(null, true);
		}
		else {
			callback(new Error('CORS policy: This domain is not allowed'));
		}
	}
};

app.use(cors(corsOptions));

//Route Handler for '/' i.e., http://localhost:5000/
app.get('/', (req, res) => {
	res.send("Welcome to the Backend API server!");
});


app.get('/api/data', (req, res) => {
	const currentTime = new Date();
	res.json({
		message:'Hello from backend!',
		timestamp: currentTime.toISOString()
	});
});

app.use((req, res, next) => {
	console.log('Received ${req.method} request for $(req.url}');
	next();
});

const PORT = 5000;
app.listen(PORT, () => {
	console.log('Backend API is running on http://localhost:$(PORT}');
});
