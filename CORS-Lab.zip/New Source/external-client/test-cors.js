const fetch = require('node-fetch');

const makeRequest = async () => {
  try {
    const response = await fetch('http://192.168.10.101:5000/api/data', {
      method: 'GET',
      headers: {
        'Origin': 'http://external-client:8000',  // Simulate unauthorized origin
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    console.log('Response from backend:', data);
  } catch (error) {
    console.error('Request failed:', error.message);
  }
};

makeRequest();

