/* g++ filename -pthread
 * pidof program
 * ps -T -p PID
 * /proc/PID/task: list thread IDs for a process
 */

#include <iostream>
#include <queue>
#include <vector>
#include <functional>
#include <thread>
#include <chrono>

using namespace std;

// Define a struct to hold event information
// function<void()> : part of the std::function template from the <functional> header 
// std::function<>: wrapper for storing callable objects such as functions, lambdas, objects with operator()//<void()>: the functions do not return any value
// (): parameter list
struct Event {
    function<void()> callback; 
};

// Event queue
queue<Event> eventQueue;

bool running = true;
//
// Function to add an event to the queue
// functon<void()>: a callable function that takes no arguments and returns void
void postEvent(function<void()> callback) {
    eventQueue.push({callback});
}

// Event loop function
void eventLoop() {
    while (running) {
        if (!eventQueue.empty()) {
            Event event = eventQueue.front();
            eventQueue.pop(); 
            event.callback(); 
        } else {
            // No events, yield to other threads
            this_thread::sleep_for(chrono::milliseconds(10)); 
        }
    }
}

// Example usage
int main() {
    // Create a thread for the event loop
    thread eventLoopThread(eventLoop); 

    // Post some events
    // []() {}: a lambda expression, aka an anonymous function
    // []: empty, doesn't capture any external variables
    // (): empty, no parameters
    // calling postEvent() with the lambda function as an argument.
    // The lambda does not return any value, so the inferred return type is void
    postEvent([]() { 
        cout << "Event 1" << endl; 
    });
    postEvent([]() { 
        cout << "Event 2" << endl; 
    });

    std::cout << "main() after posting event2" << std::endl;
    // Wait for some time (optional)
    this_thread::sleep_for(chrono::seconds(60)); 

    // Post another event
    postEvent([]() { 
        cout << "Event 3" << endl; 
    });

    // Stop the event loop after some time
    this_thread::sleep_for(chrono::seconds(3));
    running = false;

    // Wait for the event loop thread to finish

    eventLoopThread.join(); 
    std::cout << "main() after eventLoopThread.join()" << std::endl;

    return 0;
}
