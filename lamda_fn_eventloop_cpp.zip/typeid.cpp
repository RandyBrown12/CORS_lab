#include <iostream>
#include <typeinfo>

int main()
{
	int a = 10;
	double b = 3.14;

	const std::type_info& type_a = typeid(a);
	const std::type_info& type_b = typeid(b);
	

	std::cout << "Are type_a and type_b the same object? "
		//&type_a: address of type_a
		<< std::boolalpha << (&type_a == &type_b) << std::endl;

	/* std::boolalpha: a C++ stream manipulator
	 * 	modifies the behavior of the outputstream (std::cout)
	 * 	so that Boolean values are printed as "true" or "false" instead of 1 for true 0 for false
	 * 	It persists until std::noboolalpha is used
	return 0;
}
