/*
 * Use std::function for flexible lambda reassignments
 * std::function<void()> is used to store lambdas with different capture lists
 * 	, allows assigning lambdas with different types as long as the signature
 * 	is the same
 */

#include <iostream>
#include <functional>

int main()
{
	int x = 10;
	std::function<void()> func;

	func = [x]() mutable {
		x += 10;
		std::cout << "First lambda: x = " << x << std::endl;
	};
	func();

	func = [&x]() {
		x += 5;
		std::cout << "Second lambda: x = " << x << std::endl;
	};

	func();

	return 0;
}

