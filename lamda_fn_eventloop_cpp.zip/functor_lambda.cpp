#include <iostream>

class LambdaType {
	int& x;
public:
	LambdaType(int& x): x(x) {}

	void operator()() const {
		x += 10;
	}
};


int main()
{
	int x = 5;

	//compiler generates a class for auto lambda, which is unique.
	//lambda() is converted to calling operator() of the generated class.
	//Each lambda has a unique type
	//if the lambda does not modify captured values, a const operator() is defined.
	auto lambda = [&x] () {
		x += 10;
	};

	std::cout << "calling lambda()..." << std::endl;
	lambda();
	std::cout << "x = " << x << std::endl;


	LambdaType ltype(x);
	std::cout << "calling LambdaType's operator()..." << std::endl;
	ltype();
	std::cout << "x = " << x << std::endl;

	return 0;
}

