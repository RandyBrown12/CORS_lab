#include <iostream>
#include <typeinfo>

/* typeid(expression): get the type info of an expression or object at runtime
 *  part of the Run-Time Type Information (RTTI) ststem in C++
 *  returns an instance of the class std::type_info,
 *  	which contains information about the type
 *
 *  0. typeid() returns a reference to a std::type_info object, which is static and unique per type
 *  	This object is a static variable within the runtime environment and
 *  	reused for every call to typeid() involving the same type
 *  	The std::type_info object that typeid() returns is created once per type
 *  	and is shared globally for that type; it is stored internally in the program's RTTI system
 *  	It exists for the entire lifetime of the program
 *  	It is often initialized at program startup or the first used of typeid () for a type
 	
 	the return type is const std::type_info&
 *  1. typeid for primitive types and objects: returns the name of the type
 *  2. Why does typeid().name() return weird type names?
 *          - the actual output of typeid().name() depends on the compiler
 *          - GCC and Clang output manled names for types
 *          - you can demangle the type name using platform-specific tools 
 *            such as c++filt for GCC
 *  3. When to use typeid:
 *	- Debugging: determine the type of variables at runtime
 *	- Polymorphism: Check the dynamic type of polymorphic objects
 *	- Template Programming: Determine the deduced types in templates 
 *		during runtime
 *  4. name() method of std::type_info returns a mangeld type name
 *
 *
int main()
{
	int x = 5;
	auto lambda = [&x]() { x += 10; };

	lambda();
	std::cout << "x: " << x << std::endl;

	std::cout << "Lambda type: " << typeid(lambda).name() << std::endl;

	return 0;
}
