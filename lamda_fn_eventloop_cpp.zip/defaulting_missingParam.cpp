#include <iostream>

class Rectangle {
    int width, height;

public:
    // Constructor with default values for height
    Rectangle(int w, int h = 5) : width(w), height(h) {}

    int area() const {
        return width * height;
    }
};

int main() {
    Rectangle r1(10);          // ✅ OK: width = 10, height = 5 (default value used)
    Rectangle r2(10, 7);       // ✅ OK: width = 10, height = 7 (both values specified)

    std::cout << "Area of r1: " << r1.area() << std::endl;  // Output: 50 (10 * 5)
    std::cout << "Area of r2: " << r2.area() << std::endl;  // Output: 70 (10 * 7)

    Rectangle r3{10};
    Rectangle r4{10, 7}; 

    return 0;
}

