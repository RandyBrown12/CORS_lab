#include <iostream>
#include <functional>
#include <queue>

struct Event {
	std::function<void()> callback;
};

int main() {
	std::queue<Event> eventQueue;

	//initialize the callback member of 'Event using the braced initialization
	//Event e = {callback}; 
	//
	//Add an event to the queue
	//Event{} --> Event object creation
	//[]() {}: initialize callback to the lamda function
	eventQueue.push(Event{[]() {
		std::cout << "Event Triggered!" << std::endl;
	}});

	Event e = eventQueue.front();
	e.callback();

	return 0;
}
