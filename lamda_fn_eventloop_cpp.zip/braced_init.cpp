/* Aggregate types (like structs and arrays without constructors) can be initialized using curly braces {}:
 */
#include <iostream>

struct Point {
	int x;
	int y;
};


int main()
{

	Point p = {10, 20};
	std::cout << "(x, y) = " << "(" << p.x <<  ", " << p.y << ")" << std::endl;

	return 0;
}

