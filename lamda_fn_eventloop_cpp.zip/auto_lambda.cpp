#include <iostream>


int main() {
	int x = 10;
	int y = 20;

	//auto: the compiler automatically deduces the type
	//Each lambda generates a unique class types that overloads the operator(), meaning
	//the lambda essentially behaves like a functor (function object)
	//the capture list: x, &y
	//x: pass by value, making a copy of the variable x, 
	//	the captured value cannot be modified --> immutable, i.e., read-only
	auto lambda = [x, & y] () {
		std::cout << "Captured by value (x): " << x << std::endl;
		y += 10;
		std::cout << "Modified y: " << y << std::endl;
		//x += 5; cannot modify x, compile-time error
	};

	lambda();
	std::cout << "Outside lambda, x : " << x << ", y = " << y << std::endl;

	/* To reassign lambda, capture list, parameter list, return type must be the same as before.
	lambda = [x]() mutable {
		x += 5;
		std::cout << "Modified x inside lambda: " << x << std::endl;
	};

	lambda();
	std::cout << "Outside lambda, x : " << x << ", y = " << y << std::endl;
	*/
	return 0;

}

