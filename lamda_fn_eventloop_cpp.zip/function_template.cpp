#include <iostream>
#include <functional>

int main()
{
	//std::function can store function pointers, lambdas, and functors (i.e., objects with operator())
	//[]() {} : a lambda expression
	//[]: empty capture list
	std::function<void()> callback = []() {
		std::cout << "Lambda callback executed!" << std::endl;
	};

	callback();

	return 0;
}
