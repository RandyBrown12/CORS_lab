/* braced initialization, aka uniform initialization was introduced in C++11
 * aks, direct list initializaton 
 *
 * 1. Prevent Narrowing Conversion
 * 	Braced initialization prohibits narrowing conversions
 * 	int x1(4.5); 
 * 2. Uniform Initialization for All types
 * 	Aggregate types
 * 	Classed with constructors
 * 	Buil-in types
 *
 * 	In contrast, parentheses-based initializaton can only be used for types with constructors
 * 3. No "Most Vexing Parse" Issue: ambiguity in C++ syntax
 * 	MyClass obj(): declares a function obj returing myClass
 * 	MyClass obj2{}; Create an object of type MyClass
 *
 * 4. No Accidental C++98 Default Constructor Call	
 * 	struct Point { int x, y; };
 * 	Point p1; //unitialized x and y
 * 	Point p2{}; //x and y are zero-initialized
 */

#include <iostream>

struct Point {
	int x;
	int y;
};

int main() {
	Point p1 = Point{10, 20}; //Braced initialization to create an object of Point
	Point p2{30, 40}; //direct list-initialization, equivalent to Point p1(10, 20)
	//Point p1(10, 20): parentheses-based initialization
	//
	int x1(4.5); //known as direct initialization using (), since C++98, implicit narrowing conversions, causing loss of precision
	//int x2{4.5}; compile-time error

}
